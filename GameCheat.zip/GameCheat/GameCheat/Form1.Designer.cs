﻿namespace GameCheat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_cursorX = new System.Windows.Forms.TextBox();
            this.txt_cursorY = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txt_like1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_skill1 = new System.Windows.Forms.Button();
            this.txt_skill1Y = new System.Windows.Forms.TextBox();
            this.pic_file_skill1 = new System.Windows.Forms.PictureBox();
            this.txt_skill1X = new System.Windows.Forms.TextBox();
            this.pic_catch_skill1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_file_skill1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_catch_skill1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(22, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "清楚表單";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(22, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "模糊表單";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(103, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "滑鼠作標X:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(103, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "滑鼠作標Y:";
            // 
            // txt_cursorX
            // 
            this.txt_cursorX.Enabled = false;
            this.txt_cursorX.Location = new System.Drawing.Point(173, 15);
            this.txt_cursorX.Name = "txt_cursorX";
            this.txt_cursorX.Size = new System.Drawing.Size(69, 22);
            this.txt_cursorX.TabIndex = 4;
            // 
            // txt_cursorY
            // 
            this.txt_cursorY.Enabled = false;
            this.txt_cursorY.Location = new System.Drawing.Point(173, 44);
            this.txt_cursorY.Name = "txt_cursorY";
            this.txt_cursorY.Size = new System.Drawing.Size(69, 22);
            this.txt_cursorY.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txt_like1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.btn_skill1);
            this.panel1.Controls.Add(this.txt_skill1Y);
            this.panel1.Controls.Add(this.pic_file_skill1);
            this.panel1.Controls.Add(this.txt_skill1X);
            this.panel1.Controls.Add(this.pic_catch_skill1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(12, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(249, 167);
            this.panel1.TabIndex = 6;
            // 
            // txt_like1
            // 
            this.txt_like1.Enabled = false;
            this.txt_like1.Location = new System.Drawing.Point(128, 68);
            this.txt_like1.Name = "txt_like1";
            this.txt_like1.Size = new System.Drawing.Size(38, 22);
            this.txt_like1.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(79, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "相似度:";
            // 
            // btn_skill1
            // 
            this.btn_skill1.Location = new System.Drawing.Point(172, 68);
            this.btn_skill1.Name = "btn_skill1";
            this.btn_skill1.Size = new System.Drawing.Size(69, 23);
            this.btn_skill1.TabIndex = 7;
            this.btn_skill1.Text = "偵測相似";
            this.btn_skill1.UseVisualStyleBackColor = true;
            this.btn_skill1.Click += new System.EventHandler(this.btn_skill1_Click);
            // 
            // txt_skill1Y
            // 
            this.txt_skill1Y.Location = new System.Drawing.Point(149, 39);
            this.txt_skill1Y.Name = "txt_skill1Y";
            this.txt_skill1Y.Size = new System.Drawing.Size(92, 22);
            this.txt_skill1Y.TabIndex = 10;
            this.txt_skill1Y.Text = "902";
            // 
            // pic_file_skill1
            // 
            this.pic_file_skill1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_file_skill1.Location = new System.Drawing.Point(3, 79);
            this.pic_file_skill1.Name = "pic_file_skill1";
            this.pic_file_skill1.Size = new System.Drawing.Size(70, 70);
            this.pic_file_skill1.TabIndex = 1;
            this.pic_file_skill1.TabStop = false;
            this.pic_file_skill1.Click += new System.EventHandler(this.pic_file_skill1_Click);
            // 
            // txt_skill1X
            // 
            this.txt_skill1X.Location = new System.Drawing.Point(149, 10);
            this.txt_skill1X.Name = "txt_skill1X";
            this.txt_skill1X.Size = new System.Drawing.Size(92, 22);
            this.txt_skill1X.TabIndex = 9;
            this.txt_skill1X.Text = "56";
            // 
            // pic_catch_skill1
            // 
            this.pic_catch_skill1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_catch_skill1.Location = new System.Drawing.Point(3, 3);
            this.pic_catch_skill1.Name = "pic_catch_skill1";
            this.pic_catch_skill1.Size = new System.Drawing.Size(70, 70);
            this.pic_catch_skill1.TabIndex = 0;
            this.pic_catch_skill1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(79, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "設定坐標Y:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "設定坐標X:";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(248, 15);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 13;
            this.textBox1.Text = "calc";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 404);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txt_cursorY);
            this.Controls.Add(this.txt_cursorX);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_file_skill1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_catch_skill1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_cursorX;
        private System.Windows.Forms.TextBox txt_cursorY;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_skill1;
        private System.Windows.Forms.TextBox txt_skill1Y;
        private System.Windows.Forms.PictureBox pic_file_skill1;
        private System.Windows.Forms.TextBox txt_skill1X;
        private System.Windows.Forms.PictureBox pic_catch_skill1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_like1;
        private System.Windows.Forms.TextBox textBox1;
    }
}

