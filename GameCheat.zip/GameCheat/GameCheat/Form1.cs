﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
namespace GameCheat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Graphics g;
        /// <summary>
        /// 抓取技能1圖
        /// </summary>
        Bitmap file_skill1;
        /// <summary>
        /// 偵測技能1圖
        /// </summary>
        Bitmap catch_skill1;
        int[,] gray;
        int[,] gray1;
        int[,] sobel;
        int[,] sobel1;
        int[] compare;
        int[] compare1;
        IntPtr pgame;
        //定義設置活動窗口API
        [DllImport("user32.dll")]
        static extern IntPtr SetActiveWindow(IntPtr hWnd);
        //設置前台窗API   
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);
        //滑鼠點擊事件
        [DllImport("user32.dll")]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
        //滑鼠移動事件
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int X, int Y);
        private void button2_Click(object sender, EventArgs e)
        {
            this.Opacity = .7;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Opacity = 1;
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            txt_cursorX.Text = Cursor.Position.X.ToString();
            txt_cursorY.Text = Cursor.Position.Y.ToString();
        }

        private void pic_file_skill1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                file_skill1 = new Bitmap(openFileDialog1.FileName);
                pic_file_skill1.Image = file_skill1;
                btn_skill1.Enabled = true;
            }
        }

        private void btn_skill1_Click(object sender, EventArgs e)
        {
            double Edgesum;//邊緣偵測相似度
            double Colorsum;//顏色偵測相似度
            //抓第一個技能位置狀態
            catch_skill1 = new Bitmap(70, 70);
            g = Graphics.FromImage(catch_skill1);
            g.CopyFromScreen(new Point(Convert.ToInt16(txt_skill1X.Text), Convert.ToInt16(txt_skill1Y.Text)), new Point(0, 0), new Size(70, 70)); ;
            pic_catch_skill1.Image = catch_skill1;

            Bitmap outpic = new Bitmap(file_skill1, catch_skill1.Width, catch_skill1.Height);
            file_skill1 = outpic;

            //偵測的圖片轉灰階
            gray = changegray(catch_skill1);
            //抓取的圖片轉灰階
            gray1 = changegray(file_skill1);
            //灰階轉sobel
            sobel = changesobel(gray);
            //灰階轉sobel
            sobel1 = changesobel(gray1);
            compare = changecompare(sobel);
            compare1 = changecompare(sobel1);
            Edgesum = calc(compare, compare1);
            //顏色偵測function
            Colorsum = like_function(catch_skill1, file_skill1);
            //選擇偵測數最大的模式並顯示在txt上
            if (Edgesum > Colorsum) txt_like1.Text = Edgesum.ToString();
            else txt_like1.Text = Colorsum.ToString();

            //如果相似度超過95% 就點擊一次
            if (Convert.ToDouble(txt_like1.Text) >= 95)
            {
                //開啟程式
                OpenProcess("calc");
                //移動滑鼠坐標
                SetCursorPos(Convert.ToInt16(txt_skill1X.Text) + 35, Convert.ToInt16(txt_skill1Y.Text) + 35);
                //點擊一次
                mouse_event(0x0002, 0, 0, 0, 0);
                Thread.Sleep(100);
                mouse_event(0x0002, 0, 0, 0, 0);
            }

        }
        /// <summary>
        ///轉灰階存在陣列
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private int[,] changegray(Bitmap p)
        {
            //轉灰階存在陣列
            int[,] sum = new int[catch_skill1.Width, catch_skill1.Height];
            for (int x = 0; x < catch_skill1.Width; x++)
            {
                for (int y = 0; y < catch_skill1.Height; y++)
                {
                    Color c = p.GetPixel(x, y);
                    int avg = (c.R + c.B + c.G) / 3;
                    sum[x, y] = avg;
                }
            }
            return sum;
        }
        /// <summary>
        /// 灰階轉成sobel
        /// </summary>
        /// <param name="gray"></param>
        /// <returns></returns>
        private int[,] changesobel(int[,] gray)
        {
            int[,] outsobel = new int[catch_skill1.Width, catch_skill1.Height];
            int Gx, Gy;
            int sum;
            for (int x = 1; x < catch_skill1.Width - 1; x++)
            {
                for (int y = 1; y < catch_skill1.Height - 1; y++)
                {
                    Gx = (-1) * gray[x - 1, y - 1] + 0 * gray[x, y - 1] + 1 * gray[x + 1, y - 1]

                          + (-2) * gray[x - 1, y] + 0 * gray[x, y] + 2 * gray[x + 1, y]

                          + (-1) * gray[x - 1, y + 1] + 0 * gray[x, y + 1] + 1 * gray[x + 1, y + 1];


                    Gy = (1) * gray[x - 1, y - 1] + 2 * gray[x, y - 1] + 1 * gray[x + 1, y - 1]

                        + 0 * gray[x - 1, y] + 0 * gray[x, y] + 0 * gray[x + 1, y]

                        + (-1) * gray[x - 1, y + 1] + (-2) * gray[x, y + 1] + (-1) * gray[x + 1, y + 1];
                    sum = Math.Abs(Gx) + Math.Abs(Gy);
                    if (sum >= 255) sum = 255;
                    // sobel.SetPixel(x, y, Color.FromArgb(sum, sum, sum));
                    outsobel[x, y] = sum;
                }
            }
            return outsobel;
        }
        /// <summary>
        /// 轉成比對陣列
        /// </summary>
        /// <param name="sobel"></param>
        /// <returns></returns>
        private int[] changecompare(int[,] sobel)
        {
            int[] outcompare = new int[256];

            for (int x = 0; x < catch_skill1.Width; x++)   //讀取像素迴圈
            {
                for (int y = 0; y < catch_skill1.Height; y++)
                {

                    for (int i = 0; i < 256; i++)  //0~255種變化
                    {
                        if (sobel[x, y] == i)
                        {
                            outcompare[i] = outcompare[i] + 1;//累加
                        }
                    }
                }
            }
            return outcompare;
        }
        /// <summary>
        /// 計算兩圖差異
        /// </summary>
        /// <param name="compare"></param>
        /// <param name="compare1"></param>
        /// <returns></returns>
        private double calc(int[] compare, int[] compare1)
        {
            double p = 0;
            for (int i = 0; i < 255; i++)
            {
                // p+=Math.Abs( compare[i] - compare1[i]);
                if (compare[i] - compare1[i] >= 0)
                {
                    p += compare[i] - compare1[i];
                }
                else p += Math.Abs(compare[i] - compare1[i]);

            }
            return (1 - p / 9800) * 100;
        }
        private void OpenProcess(string strprocess)
        {
            //開啟指定視窗
            Process[] pros = Process.GetProcessesByName(strprocess);
            if (pros.Length != 0)
            {
                pgame = pros[0].MainWindowHandle;
                SetActiveWindow(pgame);
                SetForegroundWindow(pgame);
                Thread.Sleep(50);
            }
            else MessageBox.Show("找不到相應的視窗");
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            //一開始不能直接按偵測
            btn_skill1.Enabled = false;
        }
        public double like_function(Bitmap p1, Bitmap p2)
        {
            double sum = 0;
            for (int x = 0; x < p1.Width; x++)
            {
                for (int y = 0; y < p1.Height; y++)
                {
                    sum += Convert.ToInt16((p1.GetPixel(x, y).R - p2.GetPixel(x, y).R) + (p1.GetPixel(x, y).G - p2.GetPixel(x, y).G) + (p1.GetPixel(x, y).B - p2.GetPixel(x, y).B));
                }

            }
            sum = sum / (256 * 3 * 70 * 70);
            sum = (1 - Math.Abs(sum)) * 100;
            return sum;
        }


    }
}
