﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
namespace cursor_test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Bitmap catch_skill1;
        Bitmap file_skill1;
        Bitmap newcatchpic;
        Graphics g;
        bool a;

        int[,] gray;
        int[,] gray1;

        int[,] sobel;
        int[,] sobel1;

        int[] compare;
        int[] compare1;

        //定義設置活動窗口API
        [DllImport("user32.dll")]
        static extern IntPtr SetActiveWindow(IntPtr hWnd);
        //設置前台窗API   
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool SetForegroundWindow(IntPtr hWnd);
        //滑鼠點擊事件
        [DllImport("user32.dll")]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);
        //滑鼠移動事件
        [DllImport("user32.dll")]
        private static extern bool SetCursorPos(int X, int Y);

        private void button1_Click(object sender, EventArgs e)
        {
            catch_skill1 = new Bitmap(90, 90);
            g = Graphics.FromImage(catch_skill1);
            g.CopyFromScreen(new Point(149, 305), new Point(0, 0), new Size(90, 90)); ;
            this.pic1.Image = catch_skill1;

        }
        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            label1.Text = Cursor.Position.X.ToString() + "," + Cursor.Position.Y.ToString();
        }

        private void openfile_Click(object sender, EventArgs e)
        {

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                file_skill1 = new Bitmap(openFileDialog1.FileName);
                //file_skill1 = catch_skill1;
                pic2.Image = file_skill1;

            }
        }

        private void like(object sender, EventArgs e)
        {

            file_skill1 = change_size(catch_skill1, file_skill1);
            label2.Text = like_function(catch_skill1, file_skill1).ToString();
            Cursor.Position = new Point(Convert.ToInt16(textBox1.Text), Convert.ToInt16(textBox2.Text));

            Mouse.LeftDown();
            Thread.Sleep(100);
            Mouse.LeftUp();

        }
        public Bitmap change_size(Bitmap catch_pic, Bitmap file_pic)
        {
            Bitmap outpic = new Bitmap(file_pic, catch_pic.Size.Width, catch_pic.Size.Height);
            return outpic;
        }
        public double like_function(Bitmap p1, Bitmap p2)
        {
            double sum = 0;
            for (int x = 0; x < p1.Width; x++)
            {
                for (int y = 0; y < p1.Height; y++)
                {
                    sum += Convert.ToInt16((p1.GetPixel(x, y).R - p2.GetPixel(x, y).R) + (p1.GetPixel(x, y).G - p2.GetPixel(x, y).G) + (p1.GetPixel(x, y).B - p2.GetPixel(x, y).B));
                }

            }
            sum = sum / (256 * 3 * 90 * 90);
            sum = 1 - Math.Abs(sum);
            return sum;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Opacity = .75;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Opacity = 1;
        }
        bool x = false;
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            x = true;
            label3.Text = Cursor.Position.X.ToString() + "," + Cursor.Position.Y.ToString();
        }
        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {

        }
        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            if (x == true)
            {
                label4.Text = Cursor.Position.X.ToString() + "," + Cursor.Position.Y.ToString();

            }
            x = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //偵測的圖片
            gray = changegray(catch_skill1);
            //抓取的圖片
            gray1 = changegray(file_skill1);
        }
        /// <summary>
        ///轉灰階存在陣列
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        private int[,] changegray(Bitmap p)
        {
            //轉灰階存在陣列
            int[,] sum = new int[catch_skill1.Width, catch_skill1.Height];
            for (int x = 0; x < catch_skill1.Width; x++)
            {
                for (int y = 0; y < catch_skill1.Height; y++)
                {
                    Color c = p.GetPixel(x, y);
                    int avg = (c.R + c.B + c.G) / 3;
                    sum[x, y] = avg;
                }
            }
            return sum;
        }
        private void button5_Click(object sender, EventArgs e)
        {
            sobel = changesobel(gray);
            sobel1 = changesobel(gray1);
        }
        /// <summary>
        /// 灰階轉成sobel
        /// </summary>
        /// <param name="gray"></param>
        /// <returns></returns>
        private int[,] changesobel(int[,] gray)
        {
            int[,] outsobel = new int[catch_skill1.Width, catch_skill1.Height];
            int Gx, Gy;
            int sum;
            for (int x = 1; x < catch_skill1.Width - 1; x++)
            {
                for (int y = 1; y < catch_skill1.Height - 1; y++)
                {
                    Gx = (-1) * gray[x - 1, y - 1] + 0 * gray[x, y - 1] + 1 * gray[x + 1, y - 1]

                          + (-2) * gray[x - 1, y] + 0 * gray[x, y] + 2 * gray[x + 1, y]

                          + (-1) * gray[x - 1, y + 1] + 0 * gray[x, y + 1] + 1 * gray[x + 1, y + 1];


                    Gy = (1) * gray[x - 1, y - 1] + 2 * gray[x, y - 1] + 1 * gray[x + 1, y - 1]

                        + 0 * gray[x - 1, y] + 0 * gray[x, y] + 0 * gray[x + 1, y]

                        + (-1) * gray[x - 1, y + 1] + (-2) * gray[x, y + 1] + (-1) * gray[x + 1, y + 1];
                    sum = Math.Abs(Gx) + Math.Abs(Gy);
                    if (sum >= 255) sum = 255;
                    // sobel.SetPixel(x, y, Color.FromArgb(sum, sum, sum));
                    outsobel[x, y] = sum;
                }
            }
            return outsobel;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            //開啟指定視窗
            Process[] pros = Process.GetProcessesByName("calc");
            if (pros.Length != 0)
            {
                IntPtr pgame = pros[0].MainWindowHandle;
                SetActiveWindow(pgame);
                SetForegroundWindow(pgame);
                Thread.Sleep(50);
                SendKeys.Send("4");
                Thread.Sleep(50);
                SendKeys.Send("{ADD}");
                Thread.Sleep(50);
                SendKeys.Send("4");
                Thread.Sleep(50);
                SendKeys.Send("{=}");
            }
            else MessageBox.Show("找不到相應的視窗");
        }
        private void button7_Click(object sender, EventArgs e)
        {
            compare = changecompare(sobel);
            compare1 = changecompare(sobel1);
        }     
        /// <summary>
        /// 轉成比對陣列
        /// </summary>
        /// <param name="sobel"></param>
        /// <returns></returns>
        private int[] changecompare(int[,] sobel)
        {
            int[] outcompare = new int[256];

            for (int x = 0; x < catch_skill1.Width; x++)   //讀取像素迴圈
            {
                for (int y = 0; y < catch_skill1.Height; y++)
                {

                    for (int i = 0; i < 256; i++)  //0~255種變化
                    {
                        if (sobel[x, y] == i)
                        {
                            outcompare[i] = outcompare[i] + 1;//累加
                        }
                    }
                }
            }
            return outcompare;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            label5.Text = calc(compare,compare1).ToString();
        }
        private double calc(int[] compare, int[] compare1)
        {
            double p=0;
            for (int i = 0;i<255 ;i++ )
            {
             // p+=Math.Abs( compare[i] - compare1[i]);
                if (compare[i] - compare1[i] >= 0)
                {
                    p += compare[i] - compare1[i];
                }
                else p += Math.Abs(compare[i] - compare1[i]);

            }
            return (1-p/16200)*100;
        }    
    }
    static public class Mouse
    {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern Int32 SendInput(Int32 cInputs, ref INPUT pInputs, Int32 cbSize);

        [StructLayout(LayoutKind.Explicit, Pack = 1, Size = 28)]
        public struct INPUT
        {
            [FieldOffset(0)]
            public INPUTTYPE dwType;
            [FieldOffset(4)]
            public MOUSEINPUT mi;
            [FieldOffset(4)]
            public KEYBOARDINPUT ki;
            [FieldOffset(4)]
            public HARDWAREINPUT hi;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct MOUSEINPUT
        {
            public Int32 dx;
            public Int32 dy;
            public Int32 mouseData;
            public MOUSEFLAG dwFlags;
            public Int32 time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct KEYBOARDINPUT
        {
            public Int16 wVk;
            public Int16 wScan;
            public KEYBOARDFLAG dwFlags;
            public Int32 time;
            public IntPtr dwExtraInfo;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        public struct HARDWAREINPUT
        {
            public Int32 uMsg;
            public Int16 wParamL;
            public Int16 wParamH;
        }

        public enum INPUTTYPE : int
        {
            Mouse = 0,
            Keyboard = 1,
            Hardware = 2
        }

        [Flags()]
        public enum MOUSEFLAG : int
        {
            MOVE = 0x1,
            LEFTDOWN = 0x2,
            LEFTUP = 0x4,
            RIGHTDOWN = 0x8,
            RIGHTUP = 0x10,
            MIDDLEDOWN = 0x20,
            MIDDLEUP = 0x40,
            XDOWN = 0x80,
            XUP = 0x100,
            VIRTUALDESK = 0x400,
            WHEEL = 0x800,
            ABSOLUTE = 0x8000
        }

        [Flags()]
        public enum KEYBOARDFLAG : int
        {
            EXTENDEDKEY = 1,
            KEYUP = 2,
            UNICODE = 4,
            SCANCODE = 8
        }
        static public void LeftDown()
        {
            INPUT leftdown = new INPUT();

            leftdown.dwType = 0;
            leftdown.mi = new MOUSEINPUT();
            leftdown.mi.dwExtraInfo = IntPtr.Zero;
            leftdown.mi.dx = 0;
            leftdown.mi.dy = 0;
            leftdown.mi.time = 0;
            leftdown.mi.mouseData = 0;
            leftdown.mi.dwFlags = MOUSEFLAG.LEFTDOWN;

            SendInput(1, ref leftdown, Marshal.SizeOf(typeof(INPUT)));
        }
        static public void LeftUp()
        {
            INPUT leftup = new INPUT();

            leftup.dwType = 0;
            leftup.mi = new MOUSEINPUT();
            leftup.mi.dwExtraInfo = IntPtr.Zero;
            leftup.mi.dx = 0;
            leftup.mi.dy = 0;
            leftup.mi.time = 0;
            leftup.mi.mouseData = 0;
            leftup.mi.dwFlags = MOUSEFLAG.LEFTUP;

            SendInput(1, ref leftup, Marshal.SizeOf(typeof(INPUT)));
        }
    }

}
